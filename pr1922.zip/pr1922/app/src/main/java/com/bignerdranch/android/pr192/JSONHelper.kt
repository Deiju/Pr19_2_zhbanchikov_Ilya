package com.bignerdranch.android.pr192

import android.content.Context
import com.google.gson.Gson
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStreamReader

class JSONHelper {
    /*companion object {*/
        private val File_Name = "data.json"
        fun exportToJSON(content: Context, dataList: List<USER?>?): Boolean {
            val gson = Gson()
            val dataItems = DataItems()
            dataItems.users = dataList
            val jsonString: String = gson.toJson(dataItems)
            try {
                content.openFileOutput(File_Name, Context.MODE_PRIVATE).use { fileOutputStream ->
                    fileOutputStream.write(jsonString.toByteArray())
                    return true
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            return false
        }

        fun importFromJSON(content: Context): List<USER?>? {
            try {
                content.openFileInput(File_Name).use { fileInputStream ->
                    InputStreamReader(fileInputStream).use { streamReader ->
                        val gson = Gson()
                        val dataItems: DataItems =
                            gson.fromJson(streamReader, DataItems::class.java)
                        return dataItems.users
                    }
                }
            } catch (ex: IOException) {
                ex.printStackTrace()
            }
            return null
        }
/*}*/
private class DataItems{
    var users:List<USER?>?=null
}
}