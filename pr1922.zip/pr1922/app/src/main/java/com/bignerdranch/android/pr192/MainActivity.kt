package com.bignerdranch.android.pr192

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Adapter
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var adapter: ArrayAdapter<USER>
    lateinit var users:ArrayList<USER>
    lateinit var listview:ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listview=findViewById(R.id.ListView)
        users = ArrayList()
        adapter= ArrayAdapter(this,android.R.layout.simple_list_item_1,users)
        listview.adapter=adapter
    }
    fun addUser(view: View) {
        val name =R.id.editText2.toString()
        val age = R.id.editText.toString().toInt()
        val use = USER(name, age)
        users.add(use)
        adapter.notifyDataSetChanged()
    }
    fun save(view: View) {
        val jsonhelp=JSONHelper()
        val result =jsonhelp.exportToJSON(this, users)
        if (result) {
            Toast.makeText(this, "Данные сохранены", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Не удалось сохранить данные", Toast.LENGTH_LONG).show()
        }
    }

    fun open(view: View) {
        val jsonhelp=JSONHelper()
        users = jsonhelp.importFromJSON(this) as ArrayList<USER>
        if (users != null) {
            adapter.clear()
            adapter.addAll(users)
            Toast.makeText(this, "Данные восстановлены",
                Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Не удалось открыть данные",
                Toast.LENGTH_LONG).show()
        }
    }
}