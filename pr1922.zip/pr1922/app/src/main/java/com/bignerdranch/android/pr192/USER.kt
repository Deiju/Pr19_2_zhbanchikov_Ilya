package com.bignerdranch.android.pr192

public class USER(var name:String,var age:Int=0) {
    @Override
    fun info(){
        println("Имя: $name \nВозраст: $age")
    }
}